#include <wiringPi.h>
#include <stdio.h>

int DI = 12
int RW = 11

int DB[] = {}